i=0

while i<50
  puts "Iteracion #{i}"
  i += 1
end

50.tomes do 
  puts "Iteracion #{i}"
end


