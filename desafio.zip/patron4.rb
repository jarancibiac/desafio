
n = ARGV[0].to_i

n.times do |i|

end

for i in (1..n)
    print i%3 >0 ? i%3 : 3
end