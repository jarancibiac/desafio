n=ARGV[0].to_i

for i in (1..n)
  puts i*2
end
