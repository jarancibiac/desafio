password=ARGV[0]

texto="a"
intentos=1

while texto !=password
  texto=texto.next
  intentos += 1
end

puts "#{intentos} intentos"