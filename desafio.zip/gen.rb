def gen(n_letras)
  resultado= ""
  letra= "a"

  n_letras.times do
    resultado=resultado + letra
    letra = letra.next
  end
  resultado
end
puts gen(5)