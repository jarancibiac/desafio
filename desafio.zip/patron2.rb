
n  = ARGV[0].to_i

n.times do |i|

    if (i % 4) < 2
        puts "*"
    else
        puts "."
    end

end