n=ARGV[0].to_i
suma=0

for i in(1..n)
  suma += i*2
end

puts suma